#!/bin/bash

validate_ip()
{
	echo $1|grep "^[0-9]\{1,3\}\.\([0-9]\{1,3\}\.\)\{2\}[0-9]\{1,3\}$" > /dev/null; 

	if [ $? -ne 0 ] 
	then
		echo "here"
		return 0 
	fi
 
	ipaddr=$1

	a=`echo $ipaddr|awk -F . '{print $1}'`
	b=`echo $ipaddr|awk -F . '{print $2}'` 
	c=`echo $ipaddr|awk -F . '{print $3}'` 
	d=`echo $ipaddr|awk -F . '{print $4}'`

	for num in $a $b $c $d 
	do 
		if [ $num -gt 255 ] || [ $num -lt 0 ]
		then 
			return 0 
		fi 
	done

	return 1 
}

if [ $# != 1 ]
then
	echo "Usage: ./start.sh {configuration file}"
	exit 1
fi

ret=`stat /dev/tun0 2>/dev/null`
if [ $? != 0 ]
then
	echo "Mac TUN/TAP needs to be intalled: http://tuntaposx.sourceforge.net"
	exit 2
fi

ret=`stat $1 2>/dev/null`
if [ $? != 0 ]
then
	echo "Config file $1 does not exit"
	exit 3
fi

ret=`echo $UID`
if [ $ret != 0 ]
then
	echo "Must be root to run Postern"
	exit 4
fi

config_file=$1
vpndns="240.0.0.1"
defdns="8.8.8.8"

services=$(networksetup -listnetworkserviceorder | grep 'Hardware Port')

while read line; do
	sname=$(echo $line | awk -F  "(, )|(: )|[)]" '{print $2}')
	sdev=$(echo $line | awk -F  "(, )|(: )|[)]" '{print $4}')
	if [ -n "$sdev" ]; then
		ifconfig $sdev 2>/dev/null | grep 'status: active' > /dev/null 2>&1
		rc="$?"
		if [ "$rc" -eq 0 ]; then
			ntsvr="$sname"
			break;
		fi
	fi
done <<< "$(echo "$services")"

if [ "$ntsvr" == "" ]
then
	echo "ERROR: Could not find active network service" >&2
	exit 1
fi

dnssvr=`networksetup -getdnsservers $ntsvr | awk 'NR==1'`
if [ "$dnssvr" == "$vpndns" ]
then
	echo "ERROR: Postern may already be launched. Run stop.sh and run this script again."
	exit 2
fi

dnslistrow="$vpndns"

validate_ip $dnssvr
if [ $? == 0 ]
then
	echo "WARNING: Could not find DNS server. Use default $defdns"
	dnssvr="$defdns"
else
	IFS=$'\n'
	dnslist=`networksetup -getdnsservers $ntsvr`
	dnssvr=`echo $dnslist | awk 'NR==1'`
	for item in $dnslist
	do
		dnslistrow="$dnslistrow $item"
	done
fi

cmd="networksetup -setdnsservers \"$ntsvr\" $dnslistrow"
eval $cmd

# launch Postern
nohup ./postern $dnssvr $config_file &
