#!/bin/bash

validate_ip()
{
	echo $1|grep "^[0-9]\{1,3\}\.\([0-9]\{1,3\}\.\)\{2\}[0-9]\{1,3\}$" > /dev/null;

	if [ $? -ne 0 ]
	then
		return 0
	fi

	ipaddr=$1

	a=`echo $ipaddr|awk -F . '{print $1}'`
	b=`echo $ipaddr|awk -F . '{print $2}'`
	c=`echo $ipaddr|awk -F . '{print $3}'`
	d=`echo $ipaddr|awk -F . '{print $4}'`

	for num in $a $b $c $d
	do
		if [ $num -gt 255 ] || [ $num -lt 0 ]
		then
			return 0
		fi
	done

	return 1
}

# Check priviledge
ret=`echo $UID`
if [ $ret != 0 ]
then
	echo "Must be root to run this script"
	exit 1
fi

# Set bash delimeter to be line break
IFS=$'\n'

# VPN DNS Server
vpndns="240.0.0.1"

# Exit Postern main service
./postern_cli exit 2>/dev/null

# Get adapter list
adapters=`networksetup -listallnetworkservices |grep -v denotes`

for adapter in $adapters
do
	dnslist=`networksetup -getdnsservers $adapter`
	dnssvr=`echo $dnslist | awk '{print $1}'`

	olddnslist=""

	for item in $dnslist
	do
		if [ "$item" == "$vpndns" ]
		then
			continue
		fi

		validate_ip $item
		if [ $? == 0 ]
		then
			continue
		fi

		olddnslist="$olddnslist $item"
	done

	if [ "$olddnslist" == "" ]
	then
		olddnslist="empty"
	fi

	cmd="networksetup -setdnsservers \"$adapter\" $olddnslist"
	eval $cmd
done
